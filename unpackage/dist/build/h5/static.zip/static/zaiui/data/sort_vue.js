let _sort_data = {
	sortListData() {
		return [{
			id: 1,
			name: '苹果',
			img: '/static/images/home/grid-icon/30.png',
		},{
			id: 2,
			name: '华为',
			img: '/static/images/home/grid-icon/31.png',
		},{
			id: 3,
			name: '小米',
			img: '/static/images/home/grid-icon/32.png',
		},{
			id: 4,
			name: 'vivo',
			img: '/static/images/home/grid-icon/33.png',
		},{
			id: 5,
			name: 'oppo',
			img: '/static/images/home/grid-icon/34.png',
		},{
			id: 6,
			name: '魅族',
			img: '/static/images/home/grid-icon/35.png',
		},{
			id: 7,
			name: '寄卖优选',
			img: '/static/images/home/grid-icon/36.png',
		},{
			id: 8,
			name: '验机特惠',
			img: '/static/images/home/grid-icon/37.png',
		},{
			id: 9,
			name: '直播特卖',
			img: '/static/images/home/grid-icon/38.png',
		},{
			id: 10,
			name: '更多分类',
			img: '/static/images/home/grid-icon/39.png',
		}];
	},
};

export default _sort_data;