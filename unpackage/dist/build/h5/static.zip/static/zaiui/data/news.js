let _news_data = {
	
};

export default _news_data;