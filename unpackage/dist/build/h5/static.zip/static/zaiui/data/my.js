let _my_data = {
	toolsListData() {
		return [{
			id: 1,
			icon: 'service',
			name: '客服中心'
		},{
			id: 2,
			icon: 'squarecheck',
			name: '我的订阅'
		},{
			id: 3,
			icon: 'friend',
			name: '我的拼团'
		},{
			id: 4,
			icon: 'moneybag',
			name: '借钱'
		},{
			id: 5,
			icon: 'read',
			name: '平台规则'
		},{
			id: 6,
			icon: 'notification',
			name: '活动报名'
		},{
			id: 7,
			icon: 'redpacket',
			name: '领新人红包'
		},{
			id: 8,
			icon: 'vipcard',
			name: '办信用卡'
		},{
			id: 9,
			icon: 'scan',
			name: '活动扫码'
		},{
			id: 10,
			icon: 'present',
			name: '签到送礼'
		},{
			id: 11,
			icon: 'delete',
			name: '垃圾分类'
		},{
			id: 12,
			icon: 'mobile',
			name: '租手机'
		}];
	}
};

export default _my_data;